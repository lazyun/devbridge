import sys,subprocess,os,json,pathlib,hashlib,stat,time
ROOT=pathlib.Path('/Users/phoenix/Documents/devbridge')
OUT=ROOT/'docs/validation/v0.1-final-remaining-closure'
OUT.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env.update(GOCACHE='/private/tmp/devbridge-go-cache',GOPROXY='off',GOSUMDB='off')
packages=['./internal/mcpserver','./internal/localmcp','./internal/controlapi','./internal/workflowpresentation','./internal/bridgehttp','./internal/consoleapi','./internal/task','./internal/storage/sqlite','./internal/directfile','./internal/workflowprogression','./internal/execution','./internal/probeexecution','./internal/controlplane']
commands={
 'go-tests':['go','test','-json','-count=1']+packages,
 'race-tests':['go','test','-race','-json','-count=1','./internal/storage/sqlite','./internal/localmcp','./internal/controlapi','./internal/workflowpresentation','-run','FinalAcceptance|FinalTaskCreate|TaskAcceptanceSameFeatureAreaRace|TaskAcceptanceChanges|TaskAcceptanceReverification|TaskCreateReplay|DevelopmentWorkspace|Workspace.*(Inspection|Review|Selection)|SelectedOperation'],
 'migration-tests':['go','test','-json','-count=1','./internal/storage/sqlite','-run','Migration|TaskOwnedSchema|ReviewDepthV45'],
 'prompt-byte-identity':['go','test','-json','-count=1','./internal/execution','./internal/probeexecution','./internal/storage/sqlite','-run','PromptNeutrality|AllRunPromptBuilders|RunStorePersistsOneExactPrompt|BuildPromptReturnsAuthoredInstructionByteExact|CreateDoesNotLaunchAndRunnerUsesIndependentProbeLifecycle'],
 'acceptance-focused':['go','test','-json','-count=1','./internal/localmcp','./internal/storage/sqlite','./internal/controlapi','-run','FinalAcceptance|TaskAcceptance|TaskOwnedCrossAdapter'],
 'tool-catalog':['go','test','-v','-count=1','./internal/localmcp','-run','^TestFinalCatalogAcceptance$'],
 'go-vet':['go','vet']+packages,
 'node-tests':['node','--test']+sorted(str(p.relative_to(ROOT)) for folder in ['internal/mcpserver','internal/bridgehttp'] for p in (ROOT/folder).glob('*test.js')),
 'diff-check':['git','diff','--check'],
}
mode=sys.argv[1]
if mode=='snapshot':
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).split(b'\0')
 untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=ROOT).split(b'\0')
 files=[]
 for raw in sorted(set(tracked+untracked)):
  if not raw:continue
  name=raw.decode();p=ROOT/name
  if name.startswith('docs/validation/v0.1-final-remaining-closure/'):continue
  if not p.exists() and not p.is_symlink():files.append({'path':name,'deleted':True});continue
  data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
  files.append({'path':name,'mode':stat.S_IMODE(p.lstat().st_mode),'sha256':hashlib.sha256(data).hexdigest(),'untracked':raw in untracked})
 encoded=json.dumps(files,sort_keys=True,separators=(',',':')).encode()
 result={'baseHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'trackedPatchSHA256':hashlib.sha256(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=ROOT)).hexdigest(),'allSourceFilesSHA256':hashlib.sha256(encoded).hexdigest(),'files':files}
 dest=OUT/(sys.argv[2] if len(sys.argv)>2 else 'source-snapshot.json');dest.write_text(json.dumps(result,indent=2)+'\n');print(result['trackedPatchSHA256'],result['allSourceFilesSHA256']);sys.exit(0)
cmd=commands[mode]
if mode=='tool-catalog':env['DEVBRIDGE_FINAL_CATALOG_OUTPUT_DIR']=str(OUT/'catalogs')
logname=mode+('.txt' if mode in ['tool-catalog','go-vet','diff-check'] else '.log')
meta={'command':cmd,'cwd':str(ROOT),'environment':{'GOCACHE':env['GOCACHE'],'GOPROXY':'off','GOSUMDB':'off'},'startedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
with (OUT/logname).open('w') as stream:
 stream.write(json.dumps({'validationCommand':meta})+'\n');stream.flush()
 result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
 stream.write(json.dumps({'validationExitCode':result.returncode})+'\n')
meta['exitCode']=result.returncode
(OUT/(mode+'-result.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(mode, 'PASS' if result.returncode==0 else 'FAIL', 'exit='+str(result.returncode), str(OUT/logname))
sys.exit(result.returncode)
