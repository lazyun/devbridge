"""Seal or verify all changed/untracked content against the validated base HEAD.

The receipt must live outside the repository to avoid hashing itself. It covers
every in-repository evidence file, including this script and the final report.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def capture():
    tracked = set(filter(None, git("diff", "--name-only", "-z", "HEAD").split(b"\0")))
    untracked = set(filter(None, git("ls-files", "--others", "--exclude-standard", "-z").split(b"\0")))
    files = []
    for raw in sorted(tracked | untracked):
        name = raw.decode()
        path = ROOT / name
        item = {"path": name, "untracked": raw in untracked}
        if not path.exists() and not path.is_symlink():
            item["deleted"] = True
        else:
            data = os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
            item.update(mode=stat.S_IMODE(path.lstat().st_mode),
                        kind="symlink" if path.is_symlink() else "file",
                        bytes=len(data), sha256=sha(data))
        files.append(item)
    return {
        "baseHead": git("rev-parse", "HEAD").decode().strip(),
        "branch": git("branch", "--show-current").decode().strip(),
        "trackedPatchSHA256": sha(git("diff", "--binary", "HEAD")),
        "gitStatus": git("status", "--short", "--untracked-files=all").decode(),
        "files": files,
    }


def main():
    verify = sys.argv[1] == "--verify"
    receipt = Path(sys.argv[2] if verify else sys.argv[1]).resolve()
    if receipt.is_relative_to(ROOT):
        raise SystemExit("Receipt must be outside the repository (no self-hash).")
    payload = capture()
    if capture() != payload:
        raise SystemExit("Working tree changed during capture; rerun after freezing edits.")
    identity = sha(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode())
    result = {"format": "devbridge-validated-working-tree-v1",
              "contentIdentitySHA256": identity, "payload": payload}
    if verify:
        if json.loads(receipt.read_text()) != result:
            raise SystemExit("FAIL: current working tree differs from receipt.")
        print("PASS: current working tree exactly matches receipt.")
    else:
        receipt.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print("contentIdentitySHA256=" + identity)
    print("receiptSHA256=" + sha(receipt.read_bytes()))
    print("files=" + str(len(payload["files"])))
    print("receipt=" + str(receipt))


if __name__ == "__main__":
    main()
